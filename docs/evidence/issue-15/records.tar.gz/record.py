import datetime, json, os, pathlib, subprocess, sys, time
root=pathlib.Path('/private/tmp/repotend-15'); name=sys.argv[1]; argv=sys.argv[2:]
start=time.monotonic(); r=subprocess.run(argv,capture_output=True,text=True)
data={'argv':argv,'cwd':os.getcwd(),'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_status':r.returncode,'elapsed_seconds':time.monotonic()-start,'stdout':r.stdout,'stderr':r.stderr}
(root/(name+'.json')).write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({'record':name,'exit_status':r.returncode,'stdout_tail':r.stdout[-1600:],'stderr_tail':r.stderr[-1600:]}))

import errno, json, os, socket, stat, sys
from pathlib import Path
spec = json.loads(Path(sys.argv[1]).read_text())
result = {"nonce": spec["nonce"], "writes": {}, "reads": {}, "mode_change": None,
          "scratch": False, "network": "not_observed"}
def denied(exc):
    return "denied" if exc.errno in (errno.EPERM, errno.EACCES, errno.EROFS) else "unknown"
for name, filename in spec["writes"].items():
    try:
        Path(filename).write_text("disposable S0 write canary\n")
        result["writes"][name] = "allowed"
    except OSError as exc:
        result["writes"][name] = denied(exc)
for name, filename in spec["reads"].items():
    try:
        Path(filename).read_bytes()
        result["reads"][name] = "allowed"
    except OSError as exc:
        result["reads"][name] = denied(exc)
try:
    path = Path(spec["mode_target"])
    path.chmod(stat.S_IMODE(path.stat().st_mode) ^ stat.S_IXUSR)
    result["mode_change"] = "allowed"
except OSError as exc:
    result["mode_change"] = denied(exc)
try:
    Path(spec["scratch_file"]).write_text(spec["nonce"])
    result["scratch"] = True
except OSError:
    pass
if spec["port"] is not None:
    try:
        with socket.create_connection(("127.0.0.1", spec["port"]), timeout=1):
            result["network"] = "allowed"
    except OSError as exc:
        result["network"] = denied(exc)
print(json.dumps(result))

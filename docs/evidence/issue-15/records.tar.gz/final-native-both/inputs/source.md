## Why

RepoTend aims to be welcoming to people using a terminal for the first time. The audit CLI currently accepts `--root` and `--format json|markdown`, but it has no help output and treats an unsupported format such as `xml` as a generic unknown/incomplete option.

**Observed in source, not yet reproduced by executing the CLI:** On RepoTend `main` at `2d69cce901475380775f674b9cc5755f1f89f82e`, [`skills/repotend/scripts/cli.ts`](https://github.com/grove/repotend/blob/2d69cce901475380775f674b9cc5755f1f89f82e/skills/repotend/scripts/cli.ts) parses only `--root` and `--format` and throws `Unknown or incomplete option` for other arguments. [`audit.mjs`](https://github.com/grove/repotend/blob/2d69cce901475380775f674b9cc5755f1f89f82e/skills/repotend/scripts/audit.mjs) is the real Node entrypoint and forwards arguments. The normal audit is read-only. There is no matching open/closed product issue or PR in the returned repository inventory as of 2026-10-18.

## Original user-facing requirements

**R1 — Useful help, without performing an audit.** Running:

```sh
node skills/repotend/scripts/audit.mjs --help
```

should print a short, beginner-friendly usage explanation for this **audit** command, including `--root PATH`, `--format markdown|json` and `--help`, describe the defaults, exit **0**, and not run an audit or emit an ordinary audit report. Help output goes to stdout; no spurious failure diagnostic goes to stderr. Avoid requiring a valid target directory just to read help.

**R2 — Actionable error for a bad format, without performing an audit.** Running:

```sh
node skills/repotend/scripts/audit.mjs --format xml
```

should produce **no report on stdout**, exit nonzero (ideally retain RepoTend's existing usage/error convention, exit **2**), and explain the invalid value and the supported formats `markdown` and `json` in stderr. Do not start an audit or silently substitute a different format.

These are **two independent behaviors**: a passing help test does not demonstrate that invalid-format handling works.

## Scope and acceptance

- [ ] **R1:** `--help` works as described above, with a focused independently runnable behavioral test that observes stdout, stderr, exit status and absence of audit output/effects.
- [ ] **R2:** Unsupported `--format xml` behaves as described above, with a *separate*, independently runnable behavioral test (not merely a source grep).
- [ ] **Regression:** Normal `--root` and `--format json|markdown` behavior remains intact, including advisory WARN semantics, no target-code execution and no target modifications. Do not widen flags or redesign the audit engine. Test genuine entrypoint `audit.mjs` rather than only a private parser.
- [ ] **Clarity:** Help/error copy is consistent with existing [RepoTend documentation](https://github.com/grove/repotend/blob/2d69cce901475380775f674b9cc5755f1f89f82e/docs/GETTING_STARTED.md), including Node.js 22.16+ requirements and the default cwd/Markdown behavior.

## Foundryline Deliver experiment — separate, bounded qualification

This small, genuinely useful RepoTend improvement is also the proposed **external-product pilot** for [Foundryline Deliver #18](https://github.com/grove/foundryline/issues/18) and [requirement-trace follow-up #21](https://github.com/grove/foundryline/issues/21). The experiment does **not** change RepoTend's product requirements.

A user-approved coding agent should:

1. Capture the **complete immutable issue body** as original source `S1`, including constraints and non-goals. Preserve actual user authorization, source bytes/hash, baseline commit and issue state. Use the real pinned Intentline CLI `25e926f57e69395193fc0ac258f9e6dd2332cb18` to prepare a source-cited initial schema-1/revision-1 single-S1 draft identifying R1 and R2. Inspect it against the full source. Export the original draft through actual `export --format json`; the draft is advisory, not publication authority.
2. Implement and test **R1 and R2** in RepoTend; record the coding agent's actual work and freeze one exact code candidate commit/tree. Select at least **two independently runnable, behavior-focused test argv arrays**, one per requirement. Setup/dependency installation occurs separately; native checks must not write the frozen candidate or require network access.
3. On an **actually qualified macOS** host with Python 3.11+, Codex CLI **exactly 0.162.1** and the full pinned Proofline checkout `8e117fff4de2459637fe7f74f47ab17fc3341d84`, exercise actual `proofline.py check --intentline-export DIR --intentline-links FILE`. Supply the exact exported `source-S1.txt` and exact R-to-zero-based-check-index/**complete argv** map. First select/link only the R1 test and observe **R2 NOT DEMONSTRATED**. Then (same frozen candidate/export) select/link both tests and observe **limited** results for both R IDs. Preserve real native sandbox preflight, reports, process receipts, selected argv, source/candidate/check identities, timing and errors. **No Linux mock/ordinary CI result may be called native Proofline evidence.**
4. Safely exercise a real missing-executable, invalid-map, missing native boundary or similarly bounded negative path, and record **actual** refusal/unavailable result without changing the good candidate/export or claiming a product defect. Keep `coverage_completeness: UNKNOWN` even with both linked tests passing.
5. Have a separately started reviewer examine the original full task, implementation diff, actual raw Intentline export, selected checks, native receipts and gaps. Retain a **plain-language source R1/R2 → implementation → exact command/receipt → observed result/gap** table. Disclose reviewer independence limits.
6. Run RepoTend's existing `npm run format:check`, `npm run lint`, `npm test`, `npm run release:check`, and relevant read-only audit if feasible; distinguish standard tests from native checks. Open a **reviewable, unmerged PR in `grove/repotend`**. Prepare a Foundryline evidence handoff; any separate Foundryline repository edit, issue comment/closure or PR requires its own authorization.

## Authority and failure handling

Creating this issue is **not** permission for unattended agent execution, automatic issue creation, PR merges, deployment or applying RepoTend remediation. A coding agent is authorized to implement the RepoTend change, run selected checks and **create an unmerged RepoTend PR only when explicitly launched by the user with that scope**. A missing qualified macOS/native Proofline environment blocks the end-to-end experiment, **not** the value of an ordinary well-tested RepoTend fix; report that gap honestly.

**No new Foundryline controller, scheduler, universal adapter, mandated planning step for other RepoTend changes or broad sandbox-security claim.**

## Proposed verification — NOT YET RUN

- Observe actual baseline commands and distinguish existing behavior from what is inferred from source.
- Observe R1 and R2 separately under normal Node tests, and independent exit/stdout/stderr outcomes.
- Verify the exact candidate and full S1 source in real Intentline → Proofline receipts on a supported native host; retain both R1-only and both-R selected check runs plus a real negative.
- Independently review and open a PR **without merging**. Keep Foundryline #18/#21 open until its maintainers have evaluated the evidence.

**Definition of done:** Useful, independently tested RepoTend CLI behavior and a real, reviewable PR. The optional broader Foundryline end-to-end demonstration is considered complete only when its genuine native evidence is observed, not merely because the product tests passed.